#!/bin/bash

# This script is executed after the source is copied to the instances
cd /usr/cddemo
npm install
