#!/bin/bash

# This script is used to stop application
cd cd /usr/cddemo
pm2 stop www || true